#!/bin/sh
sudo mknod /dev/CloudUSB c 235 0 
sudo chmod 666 /dev/CloudUSB
